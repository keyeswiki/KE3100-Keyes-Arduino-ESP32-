#ifndef dash_webapge_h
#define dash_webpage_h

#include <Arduino.h>

extern const uint8_t DASH_HTML[178874];

#endif
